﻿(function () {
   angular.module('webbanhang.common', ['ui.router', 'ngBootbox', 'ngCkeditor']);
   
   
})();